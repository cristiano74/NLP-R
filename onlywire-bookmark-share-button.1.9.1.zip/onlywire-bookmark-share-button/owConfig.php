<?php

define( "SITE_NAME" , "OnlyWire");
define( "SITE_URL" , "https://www.onlywire.com/");

?>
